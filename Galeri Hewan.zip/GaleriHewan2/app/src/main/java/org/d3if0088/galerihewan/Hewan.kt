package org.d3if0088.galerihewan

data class Hewan (
    val nama: String,
    val namaLatin: String,
    val imageResId: Int
)